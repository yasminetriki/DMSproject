﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Domain.Model;  
using Domain.Data;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace DMSWebApplication.Controllers
{
    [EnableCors("MyPolicyCors")]
    [Route("api")]              // h ttp://localhost:..../api/....
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly ApplicationSettings _appSettings;
        private SignInManager<User> _signInManager;
        private readonly IConfiguration _Configuration;
        private Context _ctx;
        private readonly IAuth _authservice;
        public LoginController(UserManager<User> userManager, IOptions<ApplicationSettings> appSettings, SignInManager<User> signInManager, Context ctx, IAuthorizationEvaluator authService)
        {

            _userManager = userManager;
            _signInManager = signInManager;
            _appSettings = appSettings.Value;
            _ctx = ctx;
            _authservice = authService;

        }

        [HttpPost("login")]
        // POST : /api/login
        public async Task<IActionResult> Login(LoginModel model) => await

        // public async Task<IActionResult> Login(LoginModel model)
        // {
        // User user = await _userManager.FindByEmailAsync(model.Email);
        // bool isvalid = await _userManager.CheckPasswordAsync(user, model.Password);

        // if ( user != null && isvalid)
        // {
        // var key = Encoding.UTF8.GetBytes(Configuration["ApplicationSettings:JWT_Secret"].ToString());
        //  var key = Convert.FromBase64String(_appSettings.JWT_Secret);
        // var tokenDescriptor = new SecurityTokenDescriptor

        // {
        //  Issuer = null,              // Not required as no third-party is involved
        //  Audience = null,            // Not required as no third-party is involved
        //  IssuedAt = DateTime.UtcNow,
        // NotBefore = DateTime.UtcNow,

        // Subject = new ClaimsIdentity(new Claim[]
        // {
        //  new Claim("UserId",user.Id.ToString())
        //  }),

        //  Expires = DateTime.UtcNow.AddDays(7),
        // SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)

        //};

        //var jwtTokenHandler = new JwtSecurityTokenHandler();

        //var jwtToken = jwtTokenHandler.CreateJwtSecurityToken(tokenDescriptor);

        // var token = jwtTokenHandler.WriteToken(jwtToken);
        //return Ok(new { token });


        // }
        // else
        ///   return Ok(user != null);
        //return BadRequest("somethinkg with password  is wrong ");

        }

        [HttpPost("register")]
        [AllowAnonymous]
        //POST : /api/register
        public async Task<IActionResult> Register(RegisterModel userModel) => await _authservice.Register(userModel);
        
           // User user = new User();

            //user.UserName = userModel.Username;
            //user.Email = userModel.Email;


            //try
            //{
               // var result = await _userManager.CreateAsync(user, userModel.Password);
               // return Ok(result);
           // }
           // catch (Exception)
           // {
               // throw ;
            //}


        
    }
}
