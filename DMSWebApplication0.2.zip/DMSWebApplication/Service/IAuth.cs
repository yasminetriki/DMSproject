﻿using Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    interface IAuth
    {
        Task<object> Login(LoginModel model);
        Task<object> Register(RegisterModel userModel);
    }
}
