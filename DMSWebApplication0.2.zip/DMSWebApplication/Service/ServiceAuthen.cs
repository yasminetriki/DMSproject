﻿using Domain.Model;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    class ServiceAuthen : IAuth
    {
        public async Task<object> Login(LoginModel model)
        {
            User user = await _userManager.FindByEmailAsync(model.Email);
            bool isvalid = await _userManager.CheckPasswordAsync(user, model.Password);

            if (user != null && isvalid)
            {
                // var key = Encoding.UTF8.GetBytes(Configuration["ApplicationSettings:JWT_Secret"].ToString());
                var key = Convert.FromBase64String(_appSettings.JWT_Secret);
                var tokenDescriptor = new SecurityTokenDescriptor

                {
                    Issuer = null,              // Not required as no third-party is involved
                    Audience = null,            // Not required as no third-party is involved
                    IssuedAt = DateTime.UtcNow,
                    NotBefore = DateTime.UtcNow,

                    Subject = new ClaimsIdentity(new Claim[]
                    {
                        new Claim("UserId",user.Id.ToString())
                    }),

                    Expires = DateTime.UtcNow.AddDays(7),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)

                };

                var jwtTokenHandler = new JwtSecurityTokenHandler();

                var jwtToken = jwtTokenHandler.CreateJwtSecurityToken(tokenDescriptor);

                var token = jwtTokenHandler.WriteToken(jwtToken);
                return Ok(new { token });


            }
            else
                //   return Ok(user != null);
                return BadRequest("somethinkg with password  is wrong ");
        }

        public async Task<object> Register(RegisterModel userModel)
        {

            User user = new User();

            user.UserName = userModel.Username;
            user.Email = userModel.Email;


            try
            {
                var result = await _userManager.CreateAsync(user, userModel.Password);
                return Ok(result);
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
