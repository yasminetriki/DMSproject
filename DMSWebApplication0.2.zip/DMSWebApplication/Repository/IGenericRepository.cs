﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace Repository
{
    public interface IGenericRepository <T> where T : class
    {
        List<T> GetAll();
        T GetById(int Id);
        IEnumerable<T> Get(Expression<Func<T, bool>> predicate);
        void Add(T entity);
        void Delete(T entity);
        void Update(T entity);
        void save();
    }
}
