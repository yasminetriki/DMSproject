﻿using Domain.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository
{
    public interface IFolder
    {
        void Insert(Folder folder);
        void Delete(Folder folder);
        void Update(Folder folder);
    }
}
